#include	<setupapi.h>
#include	<devguid.h>
#include	<regstr.h>
#include	<strsafe.h>
#include	<initguid.h>
#include	"winusb.h"
#include	"usb100.h"


#define MAX_DEVPATH_LENGTH						256


#define PICOMETER_GUID							{0xD7024F71, 0x28DE, 0x4E81, 0x8A, 0x6B, 0x11, 0x3C, 0xA2, 0xBF, 0xB6, 0x0D}

#define DEVICE_VID								0x1CBE
#define DEVICE_PID								0x0234

#define DESCRIPTOR_3_LENGTH						16
#define USB_STRING_DESCRIPTOR_TYPE				0x03


typedef struct GUIDEXT
{
    unsigned long  Data1;
    unsigned short Data2;
    unsigned short Data3;
    unsigned char  Data4;
	unsigned char  Data5;
	unsigned char  Data6;
	unsigned char  Data7;
	unsigned char  Data8;
	unsigned char  Data9;
	unsigned char  Data10;
	unsigned char  Data11;

};

typedef struct
{
    HANDLE deviceHandle;
    WINUSB_INTERFACE_HANDLE winUSBHandle;
    UCHAR deviceSpeed;
    UCHAR bulkInPipe;
    UCHAR bulkOutPipe;
    HANDLE hReadEvent;

}tDeviceInfoWinUSB;


typedef struct
{
    UCHAR bLength;
    UCHAR bDescriptorType;
    WCHAR bString[DESCRIPTOR_3_LENGTH];

}USB_STRING_DESCR;


