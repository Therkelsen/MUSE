#include	<windows.h>
#include	<stdlib.h>
#include	<stdio.h>
#include	<string.h>
#include	<process.h>
#include	<debugapi.h>
#include	"resource.h"



//#define PRODUCT_VERSION			1,0,0,0
//#define PRODUCT_VERSION_STR		"1.00"

#define WINVER 0x0501			// Allow use of features specific to Windows XP or later.
#define WIN32_LEAN_AND_MEAN		// Exclude rarely-used stuff from Windows headers



#define MAX_STRING_LEN							512

#define EXCITATION_POT_MAX_LEVEL				255

#define IMP_DATA_SIZE							sizeof(struct IMP_DATA_T)
#define IMP_DATA_BUFFER_MULTIPLIER				500		//	on maximum acquisition speed at least 500ms of data can be buffered
#define RX_BUFFER_MULTIPLIER					4		//	WinUSB receive buffer size, must be at least multiple of 3 of the largest data frame to sustain bus speed
#define RX_SIZE_BYTES							(IMP_DATA_SIZE * RX_BUFFER_MULTIPLIER)
#define MUX_DATA_SIZE							12

#define CONTROL_COMMAND_BUFFER_SIZE				1008

#define NUMBER_OF_FREQUENCIES					15

#define ADDRCTRL								0xFF03

#define NR_OF_DIVIDERS							37
#define DIVIDER_INDEXES							{0, 1, 3, 6, 8, 11, 12, 14, 15, 19, 20, 22, 23, 27, 28, 30, 31, 35, 36, 38, 39, 43, 44, 45, 46, 47, 50, 51, 53, 54, 56, 57, 59, 60, 61, 62, 63}
#define DIVIDERS								{1, 2, 4, 6, 8, 10, 12, 14, 16, 20, 24, 28, 32, 40, 48, 56, 64, 80, 96, 112, 128, 160, 192, 196, 224, 256, 320, 384, 448, 512, 640, 768, 896, 1024, 1280, 1536, 1792}


typedef void *USB_HANDLE;




struct IMP_DATA_T
{
    USHORT						AddressControl;
    USHORT						DataIdentificator;
    USHORT						FrameSizeBytes;             // size must be multiple of 64-bytes
    USHORT						SysErrors;
	ULONG						MeasurementCycleCount;
	ULONG						MeasurementCyclePeriod;
    USHORT						MaxChA;
    USHORT						MinChA;
    USHORT						MaxChB;
    USHORT						MinChB;
    FLOAT						ImpedanceModule[NUMBER_OF_FREQUENCIES];
    FLOAT						ImpedancePhase[NUMBER_OF_FREQUENCIES];
    USHORT						BatteryLevel;
    USHORT						ChargerStatus;
    USHORT						GPIOState;
    USHORT						Reserved[20];
    USHORT						CRCChk16;

};

struct BUFFER_CTRL_T
{
	HANDLE						hMutex;
	HANDLE						hBufferReadyEvent;
    UCHAR						BufferDirectionFlag;
    USHORT						BufferInIdx;
    USHORT						BufferOutIdx;
};

typedef struct GLOBAL_CTRL_T
{
	USHORT						DeviceIndex;
	USB_HANDLE					hUSB;
	HANDLE						hRxThread;
	PULONG_PTR					DLLErrorEventPtr;
	PULONG_PTR					GPIOStatesPtr;
	ULONG						GPIOStates;
	PULONG_PTR					USBTransferNfoPtr;
	UCHAR						IsRxReady;
	UCHAR						CurrentRxBufferMultiplier;
	USHORT						CurrentDividerValue;
	enum						{IDLE, MEASURE, MEASUREEXT} CurrentDeviceMode;

	HANDLE						hBreakCurrentBulkRead;
	USHORT						RxRequestSizeBytes;
	HANDLE						hUSBReadMutex;
	HANDLE						hBufferMutex;
	void						*RxDataPtr;
	BYTE						RxBuffer[RX_SIZE_BYTES];
	USHORT						CtrlCmdBuffer[CONTROL_COMMAND_BUFFER_SIZE];
	struct BUFFER_CTRL_T		ImpBufCtrl;
	struct IMP_DATA_T			ImpedanceDataBuffer[IMP_DATA_BUFFER_MULTIPLIER];

};

struct RCV_DATA_FRAME_T
{

    USHORT						AddressControl;
    USHORT						DataIdentificator;

};

struct CONF_DATA_T
{
    USHORT						BinCnt;
    USHORT						DFTBins[NUMBER_OF_FREQUENCIES];
    FLOAT						ShuntImpedanceReal[NUMBER_OF_FREQUENCIES];
    FLOAT						ShuntImpedanceImaginary[NUMBER_OF_FREQUENCIES];
    FLOAT						InputCompenValReal[NUMBER_OF_FREQUENCIES];
    FLOAT						InputCompenValImaginary[NUMBER_OF_FREQUENCIES];
};




CHAR *GetErrorStr(UINT ErrStrID, DWORD SysErrCode);

void RxThreadFunc(PVOID pvoid);
DWORD SetRxTransferSize(struct GLOBAL_CTRL_T *GlobalCtrl);

DWORD SendCtrlCmd(struct GLOBAL_CTRL_T *GlobalCtrl, USHORT CmdSizeWrd);

DWORD GetStatStr( struct GLOBAL_CTRL_T *GlobalCtrl, LPSTR StrPtr);
DWORD GetMuxStr(  struct GLOBAL_CTRL_T *GlobalCtrl, LPSTR StrPtr);
DWORD GetConfData(struct GLOBAL_CTRL_T *GlobalCtrl, PBYTE DestDataPtr);

DWORD GetI2CData(struct GLOBAL_CTRL_T *GlobalCtrl, ULONG ByteCount, PBYTE DestDataPtr);

DWORD GetData(struct GLOBAL_CTRL_T *GlobalCtrl, ULONG DataSegmentCnt, PBYTE DstDataPtr, PULONG_PTR NrOfSegmentCapturedPtr);

DWORD ConnectDevice(struct GLOBAL_CTRL_T *GlobalCtrl, LPSTR DeviceSerialStrPtr);
DWORD Disconnect(struct GLOBAL_CTRL_T *GlobalCtrl);
DWORD TerminateDevice(USB_HANDLE hUSB);
DWORD WriteUSBPacket(USB_HANDLE hUSB, unsigned char *pcBuffer, DWORD ulSize, DWORD *pulWritten);
DWORD ReadUSBPacket(USB_HANDLE hUSB, unsigned char *pcBuffer, DWORD ulSize, DWORD *pulRead, DWORD ulTimeoutmS, HANDLE hBreak);



#define DEVICE_CONNECT							0x01
#define DEVICE_DISCONNECT						0x02
#define GET_ERROR								0x03
#define GET_STATUS								0x04
#define START									0x05
#define GET_DATA								0x06
#define STOP									0x07
#define SET_SAMPLINGRATE_DIVIDER				0x08
#define SET_EXCITATION_LEVEL					0x09
#define SET_INPUT_GAINS							0x0A
#define SET_SUPPLY								0x0B
#define GET_CONFIGURATION						0x0C
#define SET_GPIO								0x0D
#define I2C_TRANSFER							0x0E
#define SET_EXTERNAL_TRIGGER					0x0F

#define SET_SHUNT								0x10
#define SET_COMP								0x11
#define SET_COMPENSATION						0x12
#define GET_GPIO								0x13
#define SELECT_10X_GAIN_ADC_CHANNELS            0x14
#define SET_DAC_REF                             0x15
#define SET_DAC_VALS							0x16
#define SET_BMS_VALS							0x17
#define SET_BIN_FREQUENCIES						0x18	//Marek, send 512 values end of array stuffed with zeroes
#define SET_WINDOW_MAGNITUDE					0x19	//Marek, send 15 floats for max and 15 floats for min
#define SET_WINDOW_PHASE						0x1A	//Marek, send 15 floats for max and 15 floats for min
#define SET_WINDOW_FUNCTION						0x1B	//Marek 0 - off, 1- based on mag, 2-based on phase, 3-based on both
#define SET_ADC_PHASE							0x1C

#define IMPEDANCE_DATA_ID						0x01DD
#define ASCII_MSG_ID							0x02CC
#define CONFIG_DATA_ID							0x03DD
#define I2C_DATA_ID								0x02DD
#define GPIO_DATA_ID							0x04DD
#define MUX_DATA_ID							    0x05CC

#define STATUS_REPLY_SIZE_BYTES					58
#define GETCONF_REPLY_SIZE_BYTES				276
#define MUX_REPLY_SIZE_BYTES					12

#define DEV_STATUS_TXT_SIZE_BYTES				64

#define I2C_REPLY_SIZE_BYTES					IMP_DATA_SIZE
#define I2C_MAXIMUM_READ_SIZE_BYTES				90
#define SET_GPIO_REPLY_SIZE_BYTES				6


#define NR_OF_DAC_VALS							1000
#define NR_OF_BMS_VALS						    512   // this must be variable
#define NR_OF_BIN_VALS						    15 


//	Device specific commands

#define START_COMMAND							0x0001
#define STOP_COMMAND							0x00FF
#define STATUS_COMMAND							0x0002

#define SET_SHUNT_VALUES_COMMAND				0x0003
#define SET_COMP_VALUES_COMMAND					0x0004
#define SET_COMP_MODE_COMMAND					0x0005

#define SET_EXCITATION_LEVEL_COMMAND			0x0006
#define SET_INPUT_GAIN_COMMAND					0x0007
#define I2C_TRANSFER_COMMAND					0x0008
#define SET_EXTERNAL_TRIGGER_COMMAND			0x0009
#define SET_SUPPLY_COMMAND						0x000A
#define GET_CONF_COMMAND						0x000B
#define SET_SAMPLINGRATE_DIVIDERS_COMMAND		0x000C
#define SET_GPIO_STATE_COMMAND					0x000E
#define SELECT_10X_GAIN_ADC_COMMAND             0x000F
#define SET_ADC_PHASE_COMMAND                   0x0010
#define SET_DAC_VALUES_COMMAND                  0x0011
#define SET_BMS_VALUES_COMMAND                  0x0012
#define SET_BIN_FREQUENCIES_COMMAND             0x0013

#define SET_WINDOW_MAGNITUDE_COMMAND			0x0014	//Marek
#define SET_WINDOW_PHASE_COMMAND				0x0015	//Marek
#define SET_WINDOW_FUNCTION_COMMAND				0x0016	//Marek

#define MUX_GET_DATA							0x0030
#define MUX_SET_DATA							0x0031
#define MUX_SET_POSITION_MANUALLY				0x0032
#define MUX_RESET								0x0033
#define MUX_SELECT_TABLE						0x0034
#define MUX_STEPPING_MODE						0x0035
#define MUX_STEPPING_PERIOD						0x0036
#define MUX_EEPROM_STORE_TABLE					0x0037
#define MUX_EEPROM_TABLE_SIZE					0x0041
#define MUX_SET_EXITATION_SOURCE				0x0043
#define MUX_FRAM_TABLE_SIZE						0x0044
#define MUX_FRAM_STORE_TABLE					0x0045
#define MUX_PAUSE_AFTER_CYCLE					0x0049

#define MUX_GET_DATA_COMMAND					0x0030
#define MUX_SET_DATA_COMMAND					0x0031
#define MUX_SET_POSITION_MANUALLY_COMMAND		0x0032
#define MUX_RESET_COMMAND						0x0033
#define MUX_SELECT_TABLE_COMMAND				0x0034
#define MUX_STEPPING_MODE_COMMAND				0x0035
#define MUX_STEPPING_PERIOD_COMMAND				0x0036
#define MUX_EEPROM_STORE_TABLE_COMMAND			0x0037
#define MUX_EEPROM_TABLE_SIZE_COMMAND			0x0041 
#define MUX_SET_EXITATION_SOURCE_COMMAND		0x0043
#define MUX_FRAM_TABLE_SIZE_COMMAND				0x0044
#define MUX_FRAM_STORE_TABLE_COMMAND			0x0045
#define MUX_PAUSE_AFTER_CYCLE_COMMAND			0x0049

