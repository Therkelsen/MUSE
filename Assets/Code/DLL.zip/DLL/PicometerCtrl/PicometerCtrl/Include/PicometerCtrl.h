

#define DEVICE_CONNECT							0x01
#define DEVICE_DISCONNECT						0x02
#define GET_ERROR								0x03
#define GET_STATUS								0x04
#define START									0x05
#define GET_DATA								0x06
#define STOP									0x07
#define SET_SAMPLINGRATE_DIVIDER				0x08
#define SET_EXCITATION_LEVEL					0x09
#define SET_INPUT_GAINS							0x0A
#define SET_SUPPLY								0x0B
#define GET_CONFIGURATION						0x0C
#define SET_GPIO								0x0D
#define I2C_TRANSFER							0x0E
#define SET_EXTERNAL_TRIGGER					0x0F
#define SET_SHUNT								0x10
#define SET_COMP								0x11
#define SET_COMPENSATION						0x12
#define GET_GPIO								0x13

char *PicometerControl(
					   unsigned char Cmd,		//	byte IN
					   unsigned long ulValue,	//	32 bit unsigned integer  IN
					   unsigned long *uLPtr,	//	32 bit unsigned integer pointer IN/OUT
					   unsigned char *BytePtr	//	byte Array IN/OUT
					   );


char *GetDLLVersion(unsigned long *USBTransferNfoPtr);
