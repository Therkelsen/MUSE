//
//
//
//	Main DLL interface
//
//
//
//
//

#include	"GlobalDefs.h"
//#include	"PicometerCtrl.h"

//  PostMessage



//#define DEBUG



//	Global static variables
static struct GLOBAL_CTRL_T		*GlobalCtrlPtr;
static HINSTANCE				DLLHinstance;
static TCHAR					StrBuffer[MAX_STRING_LEN];

void WinLog(ULONG n)
{
	wchar_t buf[128];
	_snwprintf_s(buf, 128, _TRUNCATE, L"%lu \n", n);
	OutputDebugString(buf);
}


//////////////////////////////////////////////////////////////////////
//
//	When the system starts or terminates a process or thread, it 
//	calls the entry-point function for each loaded DLL using the 
//	first thread of the process. The system also calls the 
//	entry-point function for a DLL when it is loaded or unloaded 
//	using the LoadLibrary and FreeLibrary functions.
//
//////////////////////////////////////////////////////////////////////


BOOL WINAPI DllMain(HINSTANCE hinstDLL, DWORD ReasonForCall, LPVOID Reserved) // siit l�heb k�ima
{

	BOOLEAN bSuccess = TRUE;
	DLLHinstance = hinstDLL;

	//  Perform global initialization.
	switch (ReasonForCall)
	{
	case DLL_PROCESS_ATTACH:
	{
		//  For optimization. Disables the DLL_THREAD_ATTACH and DLL_THREAD_DETACH notifications for the specified dynamic-link library (DLL). This can reduce the size of the working set for some applications.
		DisableThreadLibraryCalls(hinstDLL);

		//	Initialize semaphores, mutexes, critical sections
		ZeroMemory(&StrBuffer, MAX_STRING_LEN);
		GlobalCtrlPtr = (struct GLOBAL_CTRL_T *)malloc(sizeof(struct GLOBAL_CTRL_T));
		if (GlobalCtrlPtr == NULL)
		{
			bSuccess = FALSE;
		}
		else
		{
			ZeroMemory(GlobalCtrlPtr, sizeof(struct GLOBAL_CTRL_T));

			GlobalCtrlPtr->CurrentDividerValue = 1;
			GlobalCtrlPtr->CurrentRxBufferMultiplier = RX_BUFFER_MULTIPLIER;
		}
		break;
	}

	case DLL_PROCESS_DETACH:	//	DLL is removed from caller process memory, at this point events are disabled
	{
		if (GlobalCtrlPtr->IsRxReady)
		{
			GlobalCtrlPtr->IsRxReady = FALSE;		//	clear flag to enable thrad to exit later
			CloseHandle(GlobalCtrlPtr->hRxThread);
		}

		Disconnect(GlobalCtrlPtr);	//	Check if device is connected, if yes then try to disconnect

		free(GlobalCtrlPtr);
		break;
	}
	}
	return bSuccess;
}


void CopyByteToShortArray(PSHORT DestPtr, PBYTE SrcPtr, ULONG WrdCnt)
{

	ULONG n;

	for (n = 0; n < WrdCnt; n++)
	{
		DestPtr[n] = SrcPtr[n];
	}

}

USHORT DividerIdxLookup(ULONG DividerVal, UCHAR *IdxPtr)
{
	ULONG							i;
	const USHORT					DividerIndexesLookup[NR_OF_DIVIDERS] = DIVIDER_INDEXES;
	const USHORT					DividersLookup[NR_OF_DIVIDERS] = DIVIDERS;

	for (i = 0; i < NR_OF_DIVIDERS; i++)
	{
		if (DividerVal == DividersLookup[i])
		{
			if (IdxPtr != NULL)
			{
				*IdxPtr = (UCHAR)i;
			}
			return DividerIndexesLookup[i];
		}
	}
	return 0xFFFF;	// Invalid samplingrate divider value. Expected values are: 1, 2, 4, 6, 8, 10, 12, 14, 16, 20, 24, 28, 32, 40, 48, 56, 64, 80, 96, 112, 128, 160, 192, 196, 224, 256, 320, 384, 448, 512, 640, 768, 896, 1024, 1280, 1536, 1792\n");
}


CHAR *GetErrorStr(UINT ErrStrID, DWORD ErrCode)
{

	DWORD dwRetcode, StrLen;
	TCHAR	tmpStrBfr[128];

	ZeroMemory(&StrBuffer, MAX_STRING_LEN);

	if (LoadString(DLLHinstance, ErrStrID, StrBuffer, MAX_STRING_LEN) == 0)	//	Internal error strings
	{
		sprintf_s(StrBuffer, MAX_STRING_LEN, "ERROR: Unknown error.");
		return(StrBuffer);
	}

	if (ErrStrID == IDS_SYS_ERROR)		//	WinAPI returned error strings, including codes from 1 to 14000
	{
		ZeroMemory(&tmpStrBfr, 128);
		sprintf_s(tmpStrBfr, 128, StrBuffer, ErrCode);
		StrLen = (DWORD)strlen(tmpStrBfr);
		memcpy_s(StrBuffer, MAX_STRING_LEN, tmpStrBfr, StrLen);

		dwRetcode = FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM, "%0", ErrCode, 0, &StrBuffer[StrLen], (MAX_STRING_LEN - StrLen), NULL);

		if (dwRetcode == 0)
		{
			sprintf_s(StrBuffer, MAX_STRING_LEN, "ERROR: Unknown error.");
		}
		else
		{
			StrBuffer[(dwRetcode + StrLen) - 1] = 0x00;	//	Remove trailing \r\n
			StrBuffer[(dwRetcode + StrLen) - 2] = 0x00;
		}
	}

	if (ErrStrID == IDS_DLL_INTERNAL_ERROR)	//	DLL internal errors, include err code from 14000
	{
		ZeroMemory(&tmpStrBfr, 128);
		sprintf_s(tmpStrBfr, 128, StrBuffer, ErrCode);
		StrLen = (DWORD)strlen(tmpStrBfr);
		memcpy_s(StrBuffer, MAX_STRING_LEN, tmpStrBfr, StrLen);
	}


	return(StrBuffer);

}







//////////////////////////////////////////////////////////////////////
//
//	Main control interface function
//
//////////////////////////////////////////////////////////////////////


_declspec(dllexport) CHAR *PicometerControl(UCHAR Cmd, ULONG ulValue, PULONG_PTR uLPtr, PBYTE BytePtr)
{
	DWORD dwRetcode;

	if (GlobalCtrlPtr == NULL)
	{
		return GetErrorStr(IDS_ERROR_DLL_NOT_INIT, 0);
	}

	switch (Cmd)
	{
	case DEVICE_CONNECT:
	{
		#ifdef DEBUG
			OutputDebugStringW(L"QDLL: DEVICE CONNECT COMMAND RECEIVED");
		#endif
		if ((!BytePtr) || (!uLPtr))
		{
			return GetErrorStr(IDS_ERROR_INPUT_PARAM_ERROR, 0);
		}

		if (GlobalCtrlPtr->hUSB == NULL)
		{
			dwRetcode = ConnectDevice(GlobalCtrlPtr, (LPSTR)BytePtr);
			if (dwRetcode != ERROR_SUCCESS)
			{
				return GetErrorStr(IDS_SYS_ERROR, dwRetcode);
			}
			else
			{
				*uLPtr = GlobalCtrlPtr->DeviceIndex;

				GlobalCtrlPtr->CtrlCmdBuffer[0] = ADDRCTRL;

				GlobalCtrlPtr->hUSBReadMutex = CreateMutex(NULL, FALSE, NULL);
				if (GlobalCtrlPtr->hUSBReadMutex == NULL)
				{
					dwRetcode = GetLastError();
					Disconnect(GlobalCtrlPtr);
					return GetErrorStr(IDS_SYS_ERROR, dwRetcode);
				}

				GlobalCtrlPtr->hBufferMutex = CreateMutex(NULL, FALSE, NULL);
				if (GlobalCtrlPtr->hBufferMutex == NULL)
				{
					dwRetcode = GetLastError();
					Disconnect(GlobalCtrlPtr);
					return GetErrorStr(IDS_SYS_ERROR, dwRetcode);
				}

				GlobalCtrlPtr->hBreakCurrentBulkRead = CreateEvent(NULL, FALSE, FALSE, NULL);
				if (GlobalCtrlPtr->hBreakCurrentBulkRead == NULL)
				{
					dwRetcode = GetLastError();
					Disconnect(GlobalCtrlPtr);
					return GetErrorStr(IDS_SYS_ERROR, dwRetcode);
				}

				GlobalCtrlPtr->ImpBufCtrl.hMutex = CreateMutex(NULL, FALSE, NULL);
				if (GlobalCtrlPtr->ImpBufCtrl.hMutex == NULL)
				{
					dwRetcode = GetLastError();
					Disconnect(GlobalCtrlPtr);
					return GetErrorStr(IDS_SYS_ERROR, dwRetcode);
				}

				GlobalCtrlPtr->ImpBufCtrl.hBufferReadyEvent = CreateEvent(NULL, FALSE, FALSE, NULL); // Manual reset 2. TRUE
				if (GlobalCtrlPtr->ImpBufCtrl.hBufferReadyEvent == NULL)
				{
					dwRetcode = GetLastError();
					Disconnect(GlobalCtrlPtr);
					return GetErrorStr(IDS_SYS_ERROR, dwRetcode);
				}

				GlobalCtrlPtr->RxRequestSizeBytes = SET_GPIO_REPLY_SIZE_BYTES;
				GlobalCtrlPtr->IsRxReady = TRUE;
				GlobalCtrlPtr->hRxThread = (HANDLE)_beginthread(RxThreadFunc, 0, GlobalCtrlPtr);
				if (GlobalCtrlPtr->hRxThread == (HANDLE)-1L)
				{
					dwRetcode = GetLastError();
					Disconnect(GlobalCtrlPtr);
					return GetErrorStr(IDS_SYS_ERROR, dwRetcode);
				}

			}
		}
		else
		{
			return GetErrorStr(IDS_ERROR_ALREADY_CONNECTED, 0);
		}

		break;
	}
	case DEVICE_DISCONNECT:
	{
		if (GlobalCtrlPtr->hUSB != NULL)
		{
			GlobalCtrlPtr->CurrentRxBufferMultiplier = RX_BUFFER_MULTIPLIER;
			dwRetcode = Disconnect(GlobalCtrlPtr);
			if (dwRetcode != ERROR_SUCCESS)
			{
				return GetErrorStr(IDS_SYS_ERROR, dwRetcode);
			}
		}
		else
		{
			return GetErrorStr(IDS_ERROR_ALREADY_DISCONNECTED, 0);
		}

		break;
	}
	case GET_ERROR:
	{
		if (!uLPtr)
		{
			return GetErrorStr(IDS_ERROR_INPUT_PARAM_ERROR, 0);
		}

		GlobalCtrlPtr->DLLErrorEventPtr = uLPtr;

		dwRetcode = (DWORD)*GlobalCtrlPtr->DLLErrorEventPtr;
		*GlobalCtrlPtr->DLLErrorEventPtr = 0;

		if (dwRetcode >= 14000L)
		{
			return GetErrorStr(IDS_DLL_INTERNAL_ERROR, dwRetcode);
		}

		if (dwRetcode)
		{
			return GetErrorStr(IDS_SYS_ERROR, dwRetcode);
		}
		break;
	}
	case GET_STATUS:
	{
		#ifdef DEBUG
				OutputDebugStringW(L"QDLL: GET DEVICE STATUS COMMAND RECEIVED");
		#endif
		if (!BytePtr)
		{
			#ifdef DEBUG
						OutputDebugStringW(L"QDLL: ERROR - !BytePtr");
			#endif
			return GetErrorStr(IDS_ERROR_INPUT_PARAM_ERROR, 0);
		}

		if ((GlobalCtrlPtr->hUSB != NULL) && (GlobalCtrlPtr->IsRxReady == TRUE))
		{
			if (GlobalCtrlPtr->CurrentDeviceMode != IDLE)
			{
				return GetErrorStr(IDS_NOT_IDLE_ERROR, 0);
			}

			Sleep(1);
			GlobalCtrlPtr->RxRequestSizeBytes = STATUS_REPLY_SIZE_BYTES;
			dwRetcode = SetRxTransferSize(GlobalCtrlPtr);
			if (dwRetcode != 0)
			{
				return GetErrorStr(IDS_DLL_INTERNAL_ERROR, dwRetcode);
			}

			GlobalCtrlPtr->CtrlCmdBuffer[1] = STATUS_COMMAND;

			dwRetcode = SendCtrlCmd(GlobalCtrlPtr, 2);
			if (dwRetcode != 0)
			{
				return GetErrorStr(IDS_SYS_ERROR, dwRetcode);
			}

			dwRetcode = GetStatStr(GlobalCtrlPtr, (LPSTR)BytePtr);
			if (dwRetcode != 0)
			{
				return GetErrorStr(dwRetcode, 0);
			}

			Sleep(1);
			GlobalCtrlPtr->RxRequestSizeBytes = SET_GPIO_REPLY_SIZE_BYTES;
			dwRetcode = SetRxTransferSize(GlobalCtrlPtr);
			if (dwRetcode != 0)
			{
				return GetErrorStr(IDS_DLL_INTERNAL_ERROR, dwRetcode);
			}

		}
		else
		{
			return GetErrorStr(IDS_ERROR_NOT_CONNECTED, 0);
		}

		break;
	}
	case START:
	{

		if ((GlobalCtrlPtr->hUSB != NULL) && (GlobalCtrlPtr->IsRxReady == TRUE))
		{
			if (GlobalCtrlPtr->CurrentDeviceMode != IDLE)
			{
				return GetErrorStr(IDS_ALREADY_MEASURE_ERROR, 0);
			}

			ResetEvent(GlobalCtrlPtr->ImpBufCtrl.hBufferReadyEvent);

			GlobalCtrlPtr->ImpBufCtrl.BufferInIdx = 0;
			GlobalCtrlPtr->ImpBufCtrl.BufferOutIdx = 0;
			GlobalCtrlPtr->ImpBufCtrl.BufferDirectionFlag = 0;
			ZeroMemory(&GlobalCtrlPtr->ImpedanceDataBuffer, (sizeof(struct IMP_DATA_T) * IMP_DATA_BUFFER_MULTIPLIER));

			Sleep(1);
			GlobalCtrlPtr->RxRequestSizeBytes = (USHORT)(IMP_DATA_SIZE * GlobalCtrlPtr->CurrentRxBufferMultiplier);
			dwRetcode = SetRxTransferSize(GlobalCtrlPtr);
			if (dwRetcode != 0)
			{
				return GetErrorStr(IDS_DLL_INTERNAL_ERROR, dwRetcode);
			}
			GlobalCtrlPtr->CtrlCmdBuffer[1] = START_COMMAND;
			GlobalCtrlPtr->CtrlCmdBuffer[2] = (USHORT)ulValue;
			dwRetcode = SendCtrlCmd(GlobalCtrlPtr, 3);
			if (dwRetcode != 0)
			{
				return GetErrorStr(IDS_SYS_ERROR, dwRetcode);
			}
			else
			{
				GlobalCtrlPtr->CurrentDeviceMode = MEASURE;
			}
		}
		else
		{
			return GetErrorStr(IDS_ERROR_NOT_CONNECTED, 0);
		}

		break;
	}
	case GET_DATA:
	{
		if ((ulValue == 0) || (BytePtr == NULL))
		{
			return GetErrorStr(IDS_ERROR_INPUT_PARAM_ERROR, 0);
		}

		if ((GlobalCtrlPtr->hUSB != NULL) && (GlobalCtrlPtr->IsRxReady == TRUE))
		{
			if (GlobalCtrlPtr->CurrentDeviceMode == IDLE)
			{
				return GetErrorStr(IDS_NOT_MEASURE_ERROR, 0);
			}

			dwRetcode = GetData(GlobalCtrlPtr, ulValue, BytePtr, uLPtr);
			if (dwRetcode != 0)
			{
				return GetErrorStr(dwRetcode, 0);
			}
		}
		else
		{
			return GetErrorStr(IDS_ERROR_NOT_CONNECTED, 0);
		}
		break;
	}
	case STOP:
	{
		if ((GlobalCtrlPtr->hUSB != NULL) && (GlobalCtrlPtr->IsRxReady == TRUE))
		{
			if (GlobalCtrlPtr->CurrentDeviceMode == IDLE)
			{
				return GetErrorStr(IDS_ALREADY_IDLE_ERROR, 0);
			}

			GlobalCtrlPtr->CtrlCmdBuffer[1] = STOP_COMMAND;
			dwRetcode = SendCtrlCmd(GlobalCtrlPtr, 2);
			if (dwRetcode != 0)
			{
				return GetErrorStr(IDS_SYS_ERROR, dwRetcode);
			}
			else
			{
				GlobalCtrlPtr->CurrentDeviceMode = IDLE;
				SetEvent(GlobalCtrlPtr->ImpBufCtrl.hBufferReadyEvent);

				Sleep(1);
				GlobalCtrlPtr->RxRequestSizeBytes = SET_GPIO_REPLY_SIZE_BYTES;
				dwRetcode = SetRxTransferSize(GlobalCtrlPtr);
				if (dwRetcode != 0)
				{
					return GetErrorStr(IDS_DLL_INTERNAL_ERROR, dwRetcode);
				}
			}
		}
		else
		{
			return GetErrorStr(IDS_ERROR_NOT_CONNECTED, 0);
		}

		break;
	}
	case SET_SAMPLINGRATE_DIVIDER:
	{
		if (ulValue == 0)
		{
			return GetErrorStr(IDS_ERROR_INPUT_PARAM_ERROR, 0);
		}
		if ((GlobalCtrlPtr->hUSB != NULL) && (GlobalCtrlPtr->IsRxReady == TRUE))
		{
			if (GlobalCtrlPtr->CurrentDeviceMode != IDLE)
			{
				return GetErrorStr(IDS_NOT_IDLE_ERROR, 0);
			}
			GlobalCtrlPtr->CtrlCmdBuffer[2] = DividerIdxLookup(ulValue, &GlobalCtrlPtr->CurrentRxBufferMultiplier);
			if (GlobalCtrlPtr->CtrlCmdBuffer[2] == 0xFFFF)
			{
				return GetErrorStr(IDS_INCORRECT_DIVIDER_VAL_ERROR, 0);
			}

			GlobalCtrlPtr->CurrentDividerValue = (USHORT)ulValue;
			if (GlobalCtrlPtr->CurrentDividerValue < 6)
			{
				GlobalCtrlPtr->CurrentRxBufferMultiplier = (RX_BUFFER_MULTIPLIER - GlobalCtrlPtr->CurrentRxBufferMultiplier);
			}
			else
			{
				GlobalCtrlPtr->CurrentRxBufferMultiplier = 1;
			}

			GlobalCtrlPtr->CtrlCmdBuffer[1] = SET_SAMPLINGRATE_DIVIDERS_COMMAND;
			dwRetcode = SendCtrlCmd(GlobalCtrlPtr, 3);
			if (dwRetcode != 0)
			{
				return GetErrorStr(IDS_SYS_ERROR, dwRetcode);
			}
		}
		else
		{
			return GetErrorStr(IDS_ERROR_NOT_CONNECTED, 0);
		}

		break;
	}
	case SET_EXCITATION_LEVEL:
	{
		if (ulValue > EXCITATION_POT_MAX_LEVEL)
		{
			return GetErrorStr(IDS_VALUE_OUT_OF_RANGE_ERROR, 0);
		}

		if ((GlobalCtrlPtr->hUSB != NULL) && (GlobalCtrlPtr->IsRxReady == TRUE))
		{
			GlobalCtrlPtr->CtrlCmdBuffer[1] = SET_EXCITATION_LEVEL_COMMAND;
			GlobalCtrlPtr->CtrlCmdBuffer[2] = (unsigned short)ulValue;
			dwRetcode = SendCtrlCmd(GlobalCtrlPtr, 3);
			if (dwRetcode != 0)
			{
				return GetErrorStr(IDS_SYS_ERROR, dwRetcode);
			}
		}
		else
		{
			return GetErrorStr(IDS_ERROR_NOT_CONNECTED, 0);
		}

		break;
	}
	case SET_INPUT_GAINS:
	{
		if (ulValue > 0x0000000F)
		{
			return GetErrorStr(IDS_VALUE_OUT_OF_RANGE_ERROR, 0);
		}
		if ((GlobalCtrlPtr->hUSB != NULL) && (GlobalCtrlPtr->IsRxReady == TRUE))
		{
			GlobalCtrlPtr->CtrlCmdBuffer[1] = SET_INPUT_GAIN_COMMAND;
			GlobalCtrlPtr->CtrlCmdBuffer[2] = (unsigned short)ulValue;
			dwRetcode = SendCtrlCmd(GlobalCtrlPtr, 3);
			if (dwRetcode != 0)
			{
				return GetErrorStr(IDS_SYS_ERROR, dwRetcode);
			}
		}
		else
		{
			return GetErrorStr(IDS_ERROR_NOT_CONNECTED, 0);
		}

		break;
	}
	case SET_SUPPLY:
	{
		if (ulValue > 0x00000001)
		{
			return GetErrorStr(IDS_VALUE_OUT_OF_RANGE_ERROR, 0);
		}

		if ((GlobalCtrlPtr->hUSB != NULL) && (GlobalCtrlPtr->IsRxReady == TRUE))
		{
			GlobalCtrlPtr->CtrlCmdBuffer[1] = SET_SUPPLY_COMMAND;
			GlobalCtrlPtr->CtrlCmdBuffer[2] = (unsigned short)ulValue;
			dwRetcode = SendCtrlCmd(GlobalCtrlPtr, 3);
			if (dwRetcode != 0)
			{
				return GetErrorStr(IDS_SYS_ERROR, dwRetcode);
			}
		}
		else
		{
			return GetErrorStr(IDS_ERROR_NOT_CONNECTED, 0);
		}

		break;
	}
	case GET_CONFIGURATION:
	{
		if (!BytePtr)
		{
			return GetErrorStr(IDS_ERROR_INPUT_PARAM_ERROR, 0);
		}

		if ((GlobalCtrlPtr->hUSB != NULL) && (GlobalCtrlPtr->IsRxReady == TRUE))
		{
			if (GlobalCtrlPtr->CurrentDeviceMode != IDLE)
			{
				return GetErrorStr(IDS_NOT_IDLE_ERROR, 0);
			}

			Sleep(1);
			GlobalCtrlPtr->RxRequestSizeBytes = GETCONF_REPLY_SIZE_BYTES;
			dwRetcode = SetRxTransferSize(GlobalCtrlPtr);
			if (dwRetcode != 0)
			{
				return GetErrorStr(IDS_DLL_INTERNAL_ERROR, dwRetcode);
			}

			GlobalCtrlPtr->CtrlCmdBuffer[1] = GET_CONF_COMMAND;
			dwRetcode = SendCtrlCmd(GlobalCtrlPtr, 2);
			if (dwRetcode != 0)
			{
				return GetErrorStr(IDS_SYS_ERROR, dwRetcode);
			}

			dwRetcode = GetConfData(GlobalCtrlPtr, BytePtr);
			if (dwRetcode != 0)
			{
				return GetErrorStr(dwRetcode, 0);
			}

			Sleep(1);
			GlobalCtrlPtr->RxRequestSizeBytes = SET_GPIO_REPLY_SIZE_BYTES;
			dwRetcode = SetRxTransferSize(GlobalCtrlPtr);
			if (dwRetcode != 0)
			{
				return GetErrorStr(IDS_DLL_INTERNAL_ERROR, dwRetcode);
			}

		}
		else
		{
			return GetErrorStr(IDS_ERROR_NOT_CONNECTED, 0);
		}

		break;
	}
	case I2C_TRANSFER:
	{
		if (!BytePtr)
		{
			return GetErrorStr(IDS_ERROR_INPUT_PARAM_ERROR, 0);
		}
		if (!uLPtr)
		{
			return GetErrorStr(IDS_ERROR_INPUT_PARAM_ERROR, 0);
		}
		if ((uLPtr[0] > I2C_MAXIMUM_READ_SIZE_BYTES) || (uLPtr[0] == 0))
		{
			return GetErrorStr(IDS_BYTE_COUNT_ERROR, 0);
		}
		if (uLPtr[1] > 0x0000007F)
		{
			return GetErrorStr(IDS_SLAVE_ADDR_ERROR, 0);
		}

		if ((GlobalCtrlPtr->hUSB != NULL) && (GlobalCtrlPtr->IsRxReady == TRUE))
		{
			if (uLPtr[2])	//	Write
			{
				GlobalCtrlPtr->CtrlCmdBuffer[1] = I2C_TRANSFER_COMMAND;
				GlobalCtrlPtr->CtrlCmdBuffer[2] = 0x0001;						//	write
				GlobalCtrlPtr->CtrlCmdBuffer[3] = (unsigned short)uLPtr[1];		//	SlaveAddr
				GlobalCtrlPtr->CtrlCmdBuffer[4] = (unsigned short)uLPtr[0];		//	ByteCnt

				CopyByteToShortArray(&GlobalCtrlPtr->CtrlCmdBuffer[5], BytePtr, (ULONG)uLPtr[0]);

				dwRetcode = SendCtrlCmd(GlobalCtrlPtr, (USHORT)(5 + uLPtr[0]));
				if (dwRetcode != 0)
				{
					return GetErrorStr(IDS_SYS_ERROR, dwRetcode);
				}
			}
			else			//	Read
			{
				GlobalCtrlPtr->CtrlCmdBuffer[1] = I2C_TRANSFER_COMMAND;
				GlobalCtrlPtr->CtrlCmdBuffer[2] = 0x0000;						//	read
				GlobalCtrlPtr->CtrlCmdBuffer[3] = (unsigned short)uLPtr[1];		//	SlaveAddr
				GlobalCtrlPtr->CtrlCmdBuffer[4] = (unsigned short)uLPtr[0];		//	ByteCnt

				if (GlobalCtrlPtr->CurrentDeviceMode == IDLE)
				{
					Sleep(1);
					GlobalCtrlPtr->RxRequestSizeBytes = I2C_REPLY_SIZE_BYTES;
					dwRetcode    = SetRxTransferSize(GlobalCtrlPtr);
					if (dwRetcode != 0)
					{
						return GetErrorStr(IDS_DLL_INTERNAL_ERROR, dwRetcode);
					}
				}

				dwRetcode = SendCtrlCmd(GlobalCtrlPtr, 5);
				if (dwRetcode != 0)
				{
					return GetErrorStr(IDS_SYS_ERROR, dwRetcode);
				}

				dwRetcode = GetI2CData(GlobalCtrlPtr, (ULONG)uLPtr[0], BytePtr);
				if (dwRetcode != 0)
				{
					return GetErrorStr(dwRetcode, dwRetcode);
				}

				if (GlobalCtrlPtr->CurrentDeviceMode == IDLE)
				{
					Sleep(1);
					GlobalCtrlPtr->RxRequestSizeBytes = SET_GPIO_REPLY_SIZE_BYTES;
					dwRetcode = SetRxTransferSize(GlobalCtrlPtr);
					if (dwRetcode != 0)
					{
						return GetErrorStr(IDS_DLL_INTERNAL_ERROR, dwRetcode);
					}
				}

			}
		}
		else
		{
			return GetErrorStr(IDS_ERROR_NOT_CONNECTED, 0);
		}

		break;
	}
	case SET_EXTERNAL_TRIGGER:
	{
		if (ulValue > 0x00000001)
		{
			return GetErrorStr(IDS_VALUE_OUT_OF_RANGE_ERROR, 0);
		}

		if ((GlobalCtrlPtr->hUSB != NULL) && (GlobalCtrlPtr->IsRxReady == TRUE))
		{
			if (GlobalCtrlPtr->CurrentDeviceMode == MEASURE)
			{
				return GetErrorStr(IDS_ALREADY_MEASURE_ERROR, 0);
			}

			if (ulValue == 0x00000001)
			{
				if (GlobalCtrlPtr->CurrentDeviceMode == MEASUREEXT)
				{
					return GetErrorStr(IDS_ALREADY_EXT_TRIGGER_MODE_ERROR, 0);
				}

				ResetEvent(GlobalCtrlPtr->ImpBufCtrl.hBufferReadyEvent);

				GlobalCtrlPtr->ImpBufCtrl.BufferInIdx = 0;
				GlobalCtrlPtr->ImpBufCtrl.BufferOutIdx = 0;
				GlobalCtrlPtr->ImpBufCtrl.BufferDirectionFlag = 0;
				ZeroMemory(&GlobalCtrlPtr->ImpedanceDataBuffer, (sizeof(struct IMP_DATA_T) * IMP_DATA_BUFFER_MULTIPLIER));

				Sleep(1);
				GlobalCtrlPtr->RxRequestSizeBytes = (USHORT)(IMP_DATA_SIZE * GlobalCtrlPtr->CurrentRxBufferMultiplier);
				dwRetcode = SetRxTransferSize(GlobalCtrlPtr);
				if (dwRetcode != 0)
				{
					return GetErrorStr(IDS_DLL_INTERNAL_ERROR, dwRetcode);
				}

				GlobalCtrlPtr->CtrlCmdBuffer[1] = SET_EXTERNAL_TRIGGER_COMMAND;
				GlobalCtrlPtr->CtrlCmdBuffer[2] = 0x0001;
				dwRetcode = SendCtrlCmd(GlobalCtrlPtr, 3);
				if (dwRetcode != 0)
				{
					return GetErrorStr(IDS_SYS_ERROR, dwRetcode);
				}
				else
				{
					GlobalCtrlPtr->CurrentDeviceMode = MEASUREEXT;
				}
			}
			else
			{
				if (GlobalCtrlPtr->CurrentDeviceMode == IDLE)
				{
					return GetErrorStr(IDS_ALREADY_IDLE_ERROR, 0);
				}

				GlobalCtrlPtr->CurrentDeviceMode = IDLE;
				SetEvent(GlobalCtrlPtr->ImpBufCtrl.hBufferReadyEvent);

				GlobalCtrlPtr->CtrlCmdBuffer[1] = SET_EXTERNAL_TRIGGER_COMMAND;
				GlobalCtrlPtr->CtrlCmdBuffer[2] = 0x0000;
				dwRetcode = SendCtrlCmd(GlobalCtrlPtr, 3);
				if (dwRetcode != 0)
				{
					return GetErrorStr(IDS_SYS_ERROR, dwRetcode);
				}

				Sleep(1);
				GlobalCtrlPtr->RxRequestSizeBytes = SET_GPIO_REPLY_SIZE_BYTES;
				dwRetcode = SetRxTransferSize(GlobalCtrlPtr);
				if (dwRetcode != 0)
				{
					return GetErrorStr(IDS_DLL_INTERNAL_ERROR, dwRetcode);
				}

			}
		}
		else
		{
			return GetErrorStr(IDS_ERROR_NOT_CONNECTED, 0);
		}

		break;
	}
	case SET_GPIO:
	{
		if (!uLPtr)
		{
			return GetErrorStr(IDS_ERROR_INPUT_PARAM_ERROR, 0);
		}
		if (ulValue > 0x0000003F)
		{
			return GetErrorStr(IDS_VALUE_OUT_OF_RANGE_ERROR, 0);
		}

		GlobalCtrlPtr->GPIOStatesPtr = uLPtr;

		if ((GlobalCtrlPtr->hUSB != NULL) && (GlobalCtrlPtr->IsRxReady == TRUE))
		{

			if (GlobalCtrlPtr->CurrentDeviceMode == IDLE)
			{
				Sleep(1);
				GlobalCtrlPtr->RxRequestSizeBytes = SET_GPIO_REPLY_SIZE_BYTES;
				dwRetcode = SetRxTransferSize(GlobalCtrlPtr);
				if (dwRetcode != 0)
				{
					return GetErrorStr(IDS_DLL_INTERNAL_ERROR, dwRetcode);
				}
			}

			GlobalCtrlPtr->CtrlCmdBuffer[1] = SET_GPIO_STATE_COMMAND;
			GlobalCtrlPtr->CtrlCmdBuffer[2] = (unsigned short)ulValue;
			dwRetcode = SendCtrlCmd(GlobalCtrlPtr, 3);
			if (dwRetcode != 0)
			{
				return GetErrorStr(IDS_SYS_ERROR, dwRetcode);
			}
		}
		else
		{
			return GetErrorStr(IDS_ERROR_NOT_CONNECTED, 0);
		}


		break;
	}
	case GET_GPIO:
	{
		if (!uLPtr)
		{
			return GetErrorStr(IDS_ERROR_INPUT_PARAM_ERROR, 0);
		}

		*uLPtr = GlobalCtrlPtr->GPIOStates;

		break;
	}
	case SET_SHUNT: // uploads shunt values for impedance calculation
	{
		if (!BytePtr)
		{
			return GetErrorStr(IDS_ERROR_INPUT_PARAM_ERROR, 0);
		}
		if ((GlobalCtrlPtr->hUSB != NULL) && (GlobalCtrlPtr->IsRxReady == TRUE))
		{
			GlobalCtrlPtr->CtrlCmdBuffer[1] = SET_SHUNT_VALUES_COMMAND;

			memcpy_s(&GlobalCtrlPtr->CtrlCmdBuffer[2], ((CONTROL_COMMAND_BUFFER_SIZE * 2) - 4), BytePtr, (NUMBER_OF_FREQUENCIES * 8));

			dwRetcode = SendCtrlCmd(GlobalCtrlPtr, ((NUMBER_OF_FREQUENCIES * 4) + 2));
			if (dwRetcode != 0)
			{
				return GetErrorStr(IDS_SYS_ERROR, dwRetcode);
			}
		}
		else
		{
			return GetErrorStr(IDS_ERROR_NOT_CONNECTED, 0);
		}
		break;
	}
	case SET_COMP: // uploads values for 'open compensation' , perhaps would be best to be implemented in GUI
	{
		if (!BytePtr)
		{
			return GetErrorStr(IDS_ERROR_INPUT_PARAM_ERROR, 0);
		}
		if ((GlobalCtrlPtr->hUSB != NULL) && (GlobalCtrlPtr->IsRxReady == TRUE))
		{
			GlobalCtrlPtr->CtrlCmdBuffer[1] = SET_COMP_VALUES_COMMAND;

			memcpy_s(&GlobalCtrlPtr->CtrlCmdBuffer[2], ((CONTROL_COMMAND_BUFFER_SIZE * 2) - 4), BytePtr, (NUMBER_OF_FREQUENCIES * 8));

			dwRetcode = SendCtrlCmd(GlobalCtrlPtr, ((NUMBER_OF_FREQUENCIES * 4) + 2));
			if (dwRetcode != 0)
			{
				return GetErrorStr(IDS_SYS_ERROR, dwRetcode);
			}
		}
		else
		{
			return GetErrorStr(IDS_ERROR_NOT_CONNECTED, 0);
		}

		break;
	}
	case SET_DAC_VALS: // uploads the multisine array
	{
		if (!BytePtr)
		{
			return GetErrorStr(IDS_ERROR_INPUT_PARAM_ERROR, 0);
		}
		if ((GlobalCtrlPtr->hUSB != NULL) && (GlobalCtrlPtr->IsRxReady == TRUE))
		{
			GlobalCtrlPtr->CtrlCmdBuffer[1] = SET_DAC_VALUES_COMMAND;

			memcpy_s(&GlobalCtrlPtr->CtrlCmdBuffer[2], (CONTROL_COMMAND_BUFFER_SIZE * 2), BytePtr, (NR_OF_DAC_VALS * 2));

			dwRetcode = SendCtrlCmd(GlobalCtrlPtr, (NR_OF_DAC_VALS + 2));
			if (dwRetcode != 0)
			{
				return GetErrorStr(IDS_SYS_ERROR, dwRetcode);
			}
		}
		else
		{
			return GetErrorStr(IDS_ERROR_NOT_CONNECTED, 0);
		}
		break;
	}
	case SET_BMS_VALS:  // hack change to SET_BMS_VALS:
	{
		if (!BytePtr)
		{
			return GetErrorStr(IDS_ERROR_INPUT_PARAM_ERROR, 0);
		}
		if ((GlobalCtrlPtr->hUSB != NULL) && (GlobalCtrlPtr->IsRxReady == TRUE))
		{
			GlobalCtrlPtr->CtrlCmdBuffer[1] = SET_BMS_VALUES_COMMAND;

			memcpy_s(&GlobalCtrlPtr->CtrlCmdBuffer[2], (CONTROL_COMMAND_BUFFER_SIZE * 2), BytePtr, (512 * 2));

			dwRetcode = SendCtrlCmd(GlobalCtrlPtr, (512 + 2));
			if (dwRetcode != 0)
			{
				return GetErrorStr(IDS_SYS_ERROR, dwRetcode);
			}
		}
		else
		{
			return GetErrorStr(IDS_ERROR_NOT_CONNECTED, 0);
		}
		break;
	}
	case SET_COMPENSATION: // enables or disables the internal 'open' compensation
	{
		if ((GlobalCtrlPtr->hUSB != NULL) && (GlobalCtrlPtr->IsRxReady == TRUE))
		{
			if (ulValue == 0)
			{
				GlobalCtrlPtr->CtrlCmdBuffer[2] = 0x0000;
			}
			else if (ulValue == 1)
			{
				GlobalCtrlPtr->CtrlCmdBuffer[2] = 0x00FF;
			}
			else if (ulValue == 2)
			{
				GlobalCtrlPtr->CtrlCmdBuffer[2] = 0xFF00;
			}
			else
			{
				return GetErrorStr(IDS_VALUE_OUT_OF_RANGE_ERROR, 0);
			}

			GlobalCtrlPtr->CtrlCmdBuffer[1] = SET_COMP_MODE_COMMAND;
			dwRetcode = SendCtrlCmd(GlobalCtrlPtr, 3);
			if (dwRetcode != 0)
			{
				return GetErrorStr(IDS_SYS_ERROR, dwRetcode);
			}
		}
		else
		{
			return GetErrorStr(IDS_ERROR_NOT_CONNECTED, 0);
		}

		break;
	}
	case SET_ADC_PHASE:
	{
		if ((ulValue > 79)&&(ulValue < 0))
		{
			return GetErrorStr(IDS_VALUE_OUT_OF_RANGE_ERROR, 0);
		}

		if ((GlobalCtrlPtr->hUSB != NULL) && (GlobalCtrlPtr->IsRxReady == TRUE))
		{
			GlobalCtrlPtr->CtrlCmdBuffer[1] = SET_ADC_PHASE_COMMAND;
			GlobalCtrlPtr->CtrlCmdBuffer[2] = (unsigned short)ulValue;
			dwRetcode = SendCtrlCmd(GlobalCtrlPtr, 3);
			if (dwRetcode != 0)
			{
				return GetErrorStr(IDS_SYS_ERROR, dwRetcode);
			}
		}
		else
		{
			return GetErrorStr(IDS_ERROR_NOT_CONNECTED, 0);
		}

		break;
	}
	case SET_WINDOW_MAGNITUDE: // uploads maximum and minimum magnitude values for mask function 15+15 floats
	{
		if (!BytePtr)
		{
			return GetErrorStr(IDS_ERROR_INPUT_PARAM_ERROR, 0);
		}
		if ((GlobalCtrlPtr->hUSB != NULL) && (GlobalCtrlPtr->IsRxReady == TRUE))
		{
			GlobalCtrlPtr->CtrlCmdBuffer[1] = SET_WINDOW_MAGNITUDE_COMMAND;

			memcpy_s(&GlobalCtrlPtr->CtrlCmdBuffer[2], ((CONTROL_COMMAND_BUFFER_SIZE * 2) - 4), BytePtr, (NUMBER_OF_FREQUENCIES * 8));

			dwRetcode = SendCtrlCmd(GlobalCtrlPtr, ((NUMBER_OF_FREQUENCIES * 4) + 2));
			if (dwRetcode != 0)
			{
				return GetErrorStr(IDS_SYS_ERROR, dwRetcode);
			}
		}
		else
		{
			return GetErrorStr(IDS_ERROR_NOT_CONNECTED, 0);
		}
		break;
	}
	case SET_WINDOW_PHASE: // uploads maximum and minimum phase values for mask function 15+15 floats
	{
		if (!BytePtr)
		{
			return GetErrorStr(IDS_ERROR_INPUT_PARAM_ERROR, 0);
		}
		if ((GlobalCtrlPtr->hUSB != NULL) && (GlobalCtrlPtr->IsRxReady == TRUE))
		{
			GlobalCtrlPtr->CtrlCmdBuffer[1] = SET_WINDOW_PHASE_COMMAND;

			memcpy_s(&GlobalCtrlPtr->CtrlCmdBuffer[2], ((CONTROL_COMMAND_BUFFER_SIZE * 2) - 4), BytePtr, (NUMBER_OF_FREQUENCIES * 8));

			dwRetcode = SendCtrlCmd(GlobalCtrlPtr, ((NUMBER_OF_FREQUENCIES * 4) + 2));
			if (dwRetcode != 0)
			{
				return GetErrorStr(IDS_SYS_ERROR, dwRetcode);
			}
		}
		else
		{
			return GetErrorStr(IDS_ERROR_NOT_CONNECTED, 0);
		}
		break;
	}
	case SET_WINDOW_FUNCTION: // enables or disables the mask function 0-disabled, 1-magnitude triggered, 2-phase triggered, 3-mag and ph triggered
	{
		if ((GlobalCtrlPtr->hUSB != NULL) && (GlobalCtrlPtr->IsRxReady == TRUE))
		{
			if (ulValue > 131)
			{
				return GetErrorStr(IDS_VALUE_OUT_OF_RANGE_ERROR, 0);
			}

			GlobalCtrlPtr->CtrlCmdBuffer[1] = SET_WINDOW_FUNCTION_COMMAND;
			GlobalCtrlPtr->CtrlCmdBuffer[2] = (unsigned short)ulValue;
			dwRetcode = SendCtrlCmd(GlobalCtrlPtr, 3);
			if (dwRetcode != 0)
			{
				return GetErrorStr(IDS_SYS_ERROR, dwRetcode);
			}
		}
		else
		{
			return GetErrorStr(IDS_ERROR_NOT_CONNECTED, 0);
		}

		break;
	}
	case SELECT_10X_GAIN_ADC_CHANNELS: // switches between default ADC inputs and inputs that have extra 10X amplifiers (only when supported by firmware)
	{
		if (ulValue > 0x00000001)
		{
			return GetErrorStr(IDS_VALUE_OUT_OF_RANGE_ERROR, 0);
		}

		if ((GlobalCtrlPtr->hUSB != NULL) && (GlobalCtrlPtr->IsRxReady == TRUE))
		{
			GlobalCtrlPtr->CtrlCmdBuffer[1] = SELECT_10X_GAIN_ADC_COMMAND;
			GlobalCtrlPtr->CtrlCmdBuffer[2] = (unsigned short)ulValue;
			dwRetcode = SendCtrlCmd(GlobalCtrlPtr, 3);
			if (dwRetcode != 0)
			{
				return GetErrorStr(IDS_SYS_ERROR, dwRetcode);
			}
		}
		else
		{
			return GetErrorStr(IDS_ERROR_NOT_CONNECTED, 0);
		}
		break;
	}
	case SET_BIN_FREQUENCIES:  // hack change to change measurement frequencies, sends 15 values, if less then 15 frequencies is needed, fill the rest with 0
	{
		if (!BytePtr)
		{
			return GetErrorStr(IDS_ERROR_INPUT_PARAM_ERROR, 0);
		}
		if ((GlobalCtrlPtr->hUSB != NULL) && (GlobalCtrlPtr->IsRxReady == TRUE))
		{
			GlobalCtrlPtr->CtrlCmdBuffer[1] = SET_BIN_FREQUENCIES_COMMAND;

			//memcpy_s(&GlobalCtrlPtr->CtrlCmdBuffer[2], ((CONTROL_COMMAND_BUFFER_SIZE * 2) - 4), BytePtr, (NUMBER_OF_FREQUENCIES * 8));
			memcpy_s(&GlobalCtrlPtr->CtrlCmdBuffer[2], ((CONTROL_COMMAND_BUFFER_SIZE * 2) - 4), BytePtr, (15 * 2));

			dwRetcode = SendCtrlCmd(GlobalCtrlPtr, (NR_OF_BIN_VALS + 2));
			if (dwRetcode != 0)
			{
				return GetErrorStr(IDS_SYS_ERROR, dwRetcode);
			}
		}
		else
		{
			return GetErrorStr(IDS_ERROR_NOT_CONNECTED, 0);
		}
		break;
	}
	case MUX_GET_DATA:
	{
		#ifdef DEBUG
			OutputDebugStringW(L"QDLL: GET MUX DATA COMMAND RECEIVED");
		#endif
		if (!BytePtr)
		{
			#ifdef DEBUG
				OutputDebugStringW(L"QDLL: ERROR - !BytePtr");
			#endif
			return GetErrorStr(IDS_ERROR_INPUT_PARAM_ERROR, 0);
		}

		if ((GlobalCtrlPtr->hUSB != NULL) && (GlobalCtrlPtr->IsRxReady == TRUE))
		{
			if (GlobalCtrlPtr->CurrentDeviceMode != IDLE)
			{
				return GetErrorStr(IDS_NOT_IDLE_ERROR, 0);
			}
			Sleep(1);

			GlobalCtrlPtr->RxRequestSizeBytes = STATUS_REPLY_SIZE_BYTES;
			dwRetcode = SetRxTransferSize(GlobalCtrlPtr);
			if (dwRetcode != 0)
			{
				return GetErrorStr(IDS_DLL_INTERNAL_ERROR, dwRetcode);
			};

			GlobalCtrlPtr->CtrlCmdBuffer[1] = MUX_GET_DATA_COMMAND;

			dwRetcode = SendCtrlCmd(GlobalCtrlPtr, 2);
			if (dwRetcode != 0)
			{
				return GetErrorStr(IDS_SYS_ERROR, dwRetcode);
			}
			dwRetcode = GetStatStr(GlobalCtrlPtr, (LPSTR)BytePtr);
			#ifdef DEBUG
						OutputDebugStringW((LPSTR)BytePtr);
			#endif

			//dwRetcode = GetMuxStr(GlobalCtrlPtr, (LPSTR)BytePtr);
			if (dwRetcode != 0)
			{
				return GetErrorStr(dwRetcode, 0);
			}

		}
		else
		{
			return GetErrorStr(IDS_ERROR_NOT_CONNECTED, 0);
		}

		break;
	}
	case MUX_SET_DATA: // sends configuration data to mux, 10 bytes : U16 serial,  f32 shuntR, f32 shuntC
	{
		if (!BytePtr)
		{
			return GetErrorStr(IDS_ERROR_INPUT_PARAM_ERROR, 0);
		}
		if ((GlobalCtrlPtr->hUSB != NULL) && (GlobalCtrlPtr->IsRxReady == TRUE))
		{
			GlobalCtrlPtr->CtrlCmdBuffer[1] = MUX_SET_DATA_COMMAND;

			memcpy_s(&GlobalCtrlPtr->CtrlCmdBuffer[2], ((CONTROL_COMMAND_BUFFER_SIZE * 2) - 4), BytePtr, (10*2));

			dwRetcode = SendCtrlCmd(GlobalCtrlPtr, (10 + 2));
			if (dwRetcode != 0)
			{
				return GetErrorStr(IDS_SYS_ERROR, dwRetcode);
			}
		}
		else
		{
			return GetErrorStr(IDS_ERROR_NOT_CONNECTED, 0);
		}
		break;
	}
	case MUX_SET_POSITION_MANUALLY: // switches the multiplexers outputs and inputs to values specified in given index, transmit index
	{
		if ((GlobalCtrlPtr->hUSB != NULL) && (GlobalCtrlPtr->IsRxReady == TRUE))
		{
			GlobalCtrlPtr->CtrlCmdBuffer[1] = MUX_SET_POSITION_MANUALLY_COMMAND;
			GlobalCtrlPtr->CtrlCmdBuffer[2] = (USHORT)ulValue;
			dwRetcode = SendCtrlCmd(GlobalCtrlPtr, 3);
			if (dwRetcode != 0)
			{
				return GetErrorStr(IDS_SYS_ERROR, dwRetcode);
			}
		}
		else
		{
			return GetErrorStr(IDS_ERROR_NOT_CONNECTED, 0);
		}
		break;
	}
	case MUX_RESET: // initializes mux to default settings
	{
		if (ulValue > 1 )
		{
			return GetErrorStr(IDS_ERROR_INPUT_PARAM_ERROR, 0);
		}
		if ((GlobalCtrlPtr->hUSB != NULL) && (GlobalCtrlPtr->IsRxReady == TRUE))
		{
			GlobalCtrlPtr->CtrlCmdBuffer[1] = MUX_RESET_COMMAND;
			GlobalCtrlPtr->CtrlCmdBuffer[2] = 1;
			dwRetcode = SendCtrlCmd(GlobalCtrlPtr, 3);
			if (dwRetcode != 0)
			{
				return GetErrorStr(IDS_SYS_ERROR, dwRetcode);
			}
		}
		else
		{
			return GetErrorStr(IDS_ERROR_NOT_CONNECTED, 0);
		}
		break;
	}
	case MUX_SELECT_TABLE: // selects between user eeprom table, preprogrammed tables and user FRAM table (if mux hardware has FRAM capability)
	{
		if (ulValue > 255)
		{
			return GetErrorStr(IDS_ERROR_INPUT_PARAM_ERROR, 0);
		}
		if ((GlobalCtrlPtr->hUSB != NULL) && (GlobalCtrlPtr->IsRxReady == TRUE))
		{
			GlobalCtrlPtr->CtrlCmdBuffer[1] = MUX_SELECT_TABLE_COMMAND;
			GlobalCtrlPtr->CtrlCmdBuffer[2] = (USHORT)ulValue & 0xFF;
			dwRetcode = SendCtrlCmd(GlobalCtrlPtr, 3);
			if (dwRetcode != 0)
			{
				return GetErrorStr(IDS_SYS_ERROR, dwRetcode);
			}
		}
		else
		{
			return GetErrorStr(IDS_ERROR_NOT_CONNECTED, 0);
		}
		break;
	}
	case MUX_STEPPING_MODE: // selects between manula stepping mode (0) and automatic stepping mode (1)
	{
		if (ulValue > 1)
		{
			return GetErrorStr(IDS_ERROR_INPUT_PARAM_ERROR, 0);
		}
		if ((GlobalCtrlPtr->hUSB != NULL) && (GlobalCtrlPtr->IsRxReady == TRUE))
		{
			GlobalCtrlPtr->CtrlCmdBuffer[1] = MUX_STEPPING_MODE_COMMAND;
			GlobalCtrlPtr->CtrlCmdBuffer[2] = (USHORT)ulValue & 0b1;
			dwRetcode = SendCtrlCmd(GlobalCtrlPtr, 3);
			if (dwRetcode != 0)
			{
				return GetErrorStr(IDS_SYS_ERROR, dwRetcode);
			}
		}
		else
		{
			return GetErrorStr(IDS_ERROR_NOT_CONNECTED, 0);
		}
		break;
	}
	case MUX_PAUSE_AFTER_CYCLE: // selects if the table is automatically repeated in automatic mode (0) or the operation is paused after completion of the table and mux waits for user input before initializing rerun
	{
		if (ulValue > 1)
		{
			return GetErrorStr(IDS_ERROR_INPUT_PARAM_ERROR, 0);
		}
		if ((GlobalCtrlPtr->hUSB != NULL) && (GlobalCtrlPtr->IsRxReady == TRUE))
		{
			GlobalCtrlPtr->CtrlCmdBuffer[1] = MUX_PAUSE_AFTER_CYCLE_COMMAND;
			GlobalCtrlPtr->CtrlCmdBuffer[2] = (USHORT)ulValue & 0b1;
			dwRetcode = SendCtrlCmd(GlobalCtrlPtr, 3);
			if (dwRetcode != 0)
			{
				return GetErrorStr(IDS_SYS_ERROR, dwRetcode);
			}
		}
		else
		{
			return GetErrorStr(IDS_ERROR_NOT_CONNECTED, 0);
		}
		break;
	}
	case MUX_STEPPING_PERIOD: // specifies the number of spectrums device measures while remaining on a single mux table position
	{
		if ( (ulValue == 0) || (ulValue > 0xFFFF))
		{
			return GetErrorStr(IDS_ERROR_INPUT_PARAM_ERROR, 0);
		}
		if ((GlobalCtrlPtr->hUSB != NULL) && (GlobalCtrlPtr->IsRxReady == TRUE))
		{
			GlobalCtrlPtr->CtrlCmdBuffer[1] = MUX_STEPPING_PERIOD_COMMAND;
			GlobalCtrlPtr->CtrlCmdBuffer[2] = (USHORT)ulValue & 0xFFFF;
			dwRetcode = SendCtrlCmd(GlobalCtrlPtr, 3);
			if (dwRetcode != 0)
			{
				return GetErrorStr(IDS_SYS_ERROR, dwRetcode);
			}
		}
		else
		{
			return GetErrorStr(IDS_ERROR_NOT_CONNECTED, 0);
		}
		break;
	}
	case MUX_EEPROM_STORE_TABLE: // save entire row in one command index, excit, return, sense a , sense b 
	{
		if (!BytePtr)
		{
			return GetErrorStr(IDS_ERROR_INPUT_PARAM_ERROR, 0);
		}
		if ((GlobalCtrlPtr->hUSB != NULL) && (GlobalCtrlPtr->IsRxReady == TRUE))
		{
			GlobalCtrlPtr->CtrlCmdBuffer[1] = MUX_EEPROM_STORE_TABLE_COMMAND;

			memcpy_s(&GlobalCtrlPtr->CtrlCmdBuffer[2], ((CONTROL_COMMAND_BUFFER_SIZE * 2) - 4), BytePtr, (5 * 2));

			dwRetcode = SendCtrlCmd(GlobalCtrlPtr, (5 + 2));
			if (dwRetcode != 0)
			{
				return GetErrorStr(IDS_SYS_ERROR, dwRetcode);
			}
		}
		else
		{
			return GetErrorStr(IDS_ERROR_NOT_CONNECTED, 0);
		}
		break;
	}
	case MUX_EEPROM_TABLE_SIZE: // save start index and stop index
	{
		#ifdef DEBUG
				OutputDebugStringW(L"QDLL: MUX EEPR SIZE COMMAND RECEIVED");
				WinLog(ulValue);
		#endif

		if(ulValue == 0)
		{
			return GetErrorStr(IDS_ERROR_INPUT_PARAM_ERROR, 0);
		}

		if ((GlobalCtrlPtr->hUSB != NULL) && (GlobalCtrlPtr->IsRxReady == TRUE))
		{
			GlobalCtrlPtr->CtrlCmdBuffer[1] = MUX_EEPROM_TABLE_SIZE_COMMAND;
			GlobalCtrlPtr->CtrlCmdBuffer[2] = (USHORT)ulValue & 0x00FF;
			dwRetcode = SendCtrlCmd(GlobalCtrlPtr, 3);
			if (dwRetcode != 0)
			{
				return GetErrorStr(IDS_SYS_ERROR, dwRetcode);
			}
		}
		else
		{
			return GetErrorStr(IDS_ERROR_NOT_CONNECTED, 0);
		}
		break;
	}
	case MUX_SET_EXITATION_SOURCE: // 0 - voltage excitation, 1 - current excitation (if multiplexer version supports it)
	{
		if (ulValue > 1)
		{
			return GetErrorStr(IDS_ERROR_INPUT_PARAM_ERROR, 0);
		}
		if ((GlobalCtrlPtr->hUSB != NULL) && (GlobalCtrlPtr->IsRxReady == TRUE))
		{
			GlobalCtrlPtr->CtrlCmdBuffer[1] = MUX_SET_EXITATION_SOURCE_COMMAND;
			GlobalCtrlPtr->CtrlCmdBuffer[2] = (USHORT)ulValue & 0b1;
			dwRetcode = SendCtrlCmd(GlobalCtrlPtr, 3);
			if (dwRetcode != 0)
			{
				return GetErrorStr(IDS_SYS_ERROR, dwRetcode);
			}
		}
		else
		{
			return GetErrorStr(IDS_ERROR_NOT_CONNECTED, 0);
		}
		break;
	}
	case MUX_FRAM_TABLE_SIZE: // specifies the size of the user FRAM table, table is executed from 0 to table size value
	{
		if (ulValue == 0)
		{
			return GetErrorStr(IDS_ERROR_INPUT_PARAM_ERROR, 0);
		}
		if ((GlobalCtrlPtr->hUSB != NULL) && (GlobalCtrlPtr->IsRxReady == TRUE))
		{
			GlobalCtrlPtr->CtrlCmdBuffer[1] = MUX_FRAM_TABLE_SIZE_COMMAND;
			GlobalCtrlPtr->CtrlCmdBuffer[2] = (USHORT)ulValue & 0xFFFF;
			dwRetcode = SendCtrlCmd(GlobalCtrlPtr, 3);
			if (dwRetcode != 0)
			{
				return GetErrorStr(IDS_SYS_ERROR, dwRetcode);
			}
		}
		else
		{
			return GetErrorStr(IDS_ERROR_NOT_CONNECTED, 0);
		}
		break;
	}
	case MUX_FRAM_STORE_TABLE: // save entire row in one command index, excit, return, sense a , sense b 
	{
		if (!BytePtr)
		{
			return GetErrorStr(IDS_ERROR_INPUT_PARAM_ERROR, 0);
		}
		if ((GlobalCtrlPtr->hUSB != NULL) && (GlobalCtrlPtr->IsRxReady == TRUE))
		{
			GlobalCtrlPtr->CtrlCmdBuffer[1] = MUX_FRAM_STORE_TABLE_COMMAND;

			memcpy_s(&GlobalCtrlPtr->CtrlCmdBuffer[2], ((CONTROL_COMMAND_BUFFER_SIZE * 2) - 4), BytePtr, (5 * 2));

			dwRetcode = SendCtrlCmd(GlobalCtrlPtr, (5 + 2));
			if (dwRetcode != 0)
			{
				return GetErrorStr(IDS_SYS_ERROR, dwRetcode);
			}
		}
		else
		{
			return GetErrorStr(IDS_ERROR_NOT_CONNECTED, 0);
		}
		break;
	}




	default:
	{
		return GetErrorStr(IDS_ERROR_UNKNOWN_COMMAND, 0);
		break;
	}


	}


	return NO_ERROR;
}


//////////////////////////////////////////////////////////////////////
//
//	Sends DLL version number
//
//////////////////////////////////////////////////////////////////////


_declspec(dllexport) CHAR *GetDLLVersion(PULONG_PTR uLPtr)
{

	GlobalCtrlPtr->USBTransferNfoPtr = uLPtr;

	sprintf_s(StrBuffer, MAX_STRING_LEN, "%s", PRODUCT_VERSION_STR);

	return(StrBuffer);

}
