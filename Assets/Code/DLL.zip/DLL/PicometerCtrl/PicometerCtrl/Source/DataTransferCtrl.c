//
//
//
//	Rx Thread+Extraction and Tx data
//
//
//
//
//

#include	"GlobalDefs.h"

// last err code 14004, 1, 2

/*
struct
{

	ULONG InIdxs[1000];
	ULONG OutIdxs[1000];
	ULONG DirFlag[1000];
	ULONG OvFl[1000];
	ULONG CallID[1000];
	ULONG Cnt;

} BufIndexes = {0};

static 	ULONG OvFlVal = 0;



	BufIndexes.InIdxs[BufIndexes.Cnt] = BuffCtrlPtr->BufferInIdx;
	BufIndexes.OutIdxs[BufIndexes.Cnt] = BuffCtrlPtr->BufferOutIdx;
	BufIndexes.DirFlag[BufIndexes.Cnt] = BuffCtrlPtr->BufferDirectionFlag;
	BufIndexes.OvFl[BufIndexes.Cnt] = OvFlVal;
	BufIndexes.CallID[BufIndexes.Cnt] = ClID;
	OvFlVal = 0;
	BufIndexes.Cnt++;
	if(BufIndexes.Cnt > 1000)
		{
		BufIndexes.Cnt = 0;
		}
	OvFlVal = 14004L;



void PollForEventReset(HANDLE hEvent, ULONG MilliSeconds)  // PollForEventReset(BuffCtrlPtr->hBufferReadyEvent, 10);
{

	ULONG n = 0;

	while(n < MilliSeconds)
		{
		if(WaitForSingleObject(hEvent, 0) != WAIT_OBJECT_0)
			{
			ResetEvent(hEvent);
			return;
			}
		n++;
		Sleep(1);
		}
}
*/

void BufferUpdate(struct BUFFER_CTRL_T *BuffCtrlPtr, unsigned short InBufferIdxIncrement, unsigned short OutBufferIdxIncrement, PULONG_PTR ErrEventPtr)
{

	WaitForSingleObject(BuffCtrlPtr->hMutex, 10);

    BuffCtrlPtr->BufferInIdx += InBufferIdxIncrement;
    BuffCtrlPtr->BufferOutIdx += OutBufferIdxIncrement;

    if(BuffCtrlPtr->BufferDirectionFlag == 0x00)
        {
        if(BuffCtrlPtr->BufferInIdx > BuffCtrlPtr->BufferOutIdx)
            {
			SetEvent(BuffCtrlPtr->hBufferReadyEvent);
            }
        else
            {
            if(BuffCtrlPtr->BufferInIdx < BuffCtrlPtr->BufferOutIdx)
                {
                // buffer overflow
				if(ErrEventPtr)
					{
					*ErrEventPtr = 14004L;
					}
                }
            }
        }
    else
        {
        if(BuffCtrlPtr->BufferInIdx < BuffCtrlPtr->BufferOutIdx)
            {
			SetEvent(BuffCtrlPtr->hBufferReadyEvent);
            }
        else
            {
            if(BuffCtrlPtr->BufferInIdx > BuffCtrlPtr->BufferOutIdx)
                {
                // buffer overflow
				if(ErrEventPtr)
					{
					*ErrEventPtr = 14004L;
					}
                }
            }
        }
        
    if(BuffCtrlPtr->BufferInIdx > (IMP_DATA_BUFFER_MULTIPLIER - 1))
        {
        BuffCtrlPtr->BufferInIdx = 0;
        BuffCtrlPtr->BufferDirectionFlag ^= 0xFF;
        }

    if(BuffCtrlPtr->BufferOutIdx > (IMP_DATA_BUFFER_MULTIPLIER - 1))
        {
        BuffCtrlPtr->BufferOutIdx = 0;
        BuffCtrlPtr->BufferDirectionFlag ^= 0xFF;
		ResetEvent(BuffCtrlPtr->hBufferReadyEvent);
        }

	ReleaseMutex(BuffCtrlPtr->hMutex);

}




void ExtractData(struct GLOBAL_CTRL_T *GlobalCtrl, ULONG RxByteCount)
{

    struct RCV_DATA_FRAME_T    *FrameHdrPtr;
	ULONG						CurrentByteIdx = 0;

    if(RxByteCount > RX_SIZE_BYTES)
        {
        return;
        }

    FrameHdrPtr = (struct RCV_DATA_FRAME_T *)&GlobalCtrl->RxBuffer[CurrentByteIdx];

    while(CurrentByteIdx < RxByteCount)
        {
        if(FrameHdrPtr->AddressControl == ADDRCTRL)
            {
			switch(FrameHdrPtr->DataIdentificator)
                {
                case ASCII_MSG_ID:	//	ASCII text message received
                    {
					GlobalCtrl->RxDataPtr = (void *)&GlobalCtrl->RxBuffer[CurrentByteIdx + sizeof(struct RCV_DATA_FRAME_T)]; // Pass buffer pointer for the received payload data to data processing thread

					ReleaseMutex(GlobalCtrl->hBufferMutex);

					WaitForSingleObject(GlobalCtrl->hBufferMutex, 100);		//	Wait until interface thread processes the data

                    CurrentByteIdx += STATUS_REPLY_SIZE_BYTES;
                    break;
                    }

                case IMPEDANCE_DATA_ID:	//	Impedance data frame received
                    {
					if(GlobalCtrl->CurrentDeviceMode != IDLE)
						{
						memcpy_s(&GlobalCtrl->ImpedanceDataBuffer[GlobalCtrl->ImpBufCtrl.BufferInIdx], (IMP_DATA_SIZE * IMP_DATA_BUFFER_MULTIPLIER), &GlobalCtrl->RxBuffer[CurrentByteIdx], IMP_DATA_SIZE);

						BufferUpdate(&GlobalCtrl->ImpBufCtrl, 1, 0, GlobalCtrl->DLLErrorEventPtr);
						}
                    CurrentByteIdx += IMP_DATA_SIZE;
                    break;
                    }
                case CONFIG_DATA_ID:
                    {
					GlobalCtrl->RxDataPtr = (void *)&GlobalCtrl->RxBuffer[CurrentByteIdx + sizeof(struct RCV_DATA_FRAME_T)];

					ReleaseMutex(GlobalCtrl->hBufferMutex);

					WaitForSingleObject(GlobalCtrl->hBufferMutex, 100);

                    CurrentByteIdx += GETCONF_REPLY_SIZE_BYTES;
                    break;
                    }

				case I2C_DATA_ID:	//	I2C read data received
					{

					GlobalCtrl->RxDataPtr = (void *)&GlobalCtrl->RxBuffer[CurrentByteIdx + 10]; // 10 - RCV_DATA_FRAME_T+I2C conf data bytes

					ReleaseMutex(GlobalCtrl->hBufferMutex);

					WaitForSingleObject(GlobalCtrl->hBufferMutex, 100);

					CurrentByteIdx += I2C_REPLY_SIZE_BYTES;
					break;
					}

				case GPIO_DATA_ID:	//	GPIO data received
					{
					GlobalCtrl->RxDataPtr = (void *)&GlobalCtrl->RxBuffer[CurrentByteIdx + sizeof(struct RCV_DATA_FRAME_T)];
					memcpy_s(&GlobalCtrl->GPIOStates, 4, GlobalCtrl->RxDataPtr, (SET_GPIO_REPLY_SIZE_BYTES - 4));
					if(GlobalCtrl->GPIOStatesPtr)
						{
						*GlobalCtrl->GPIOStatesPtr = GlobalCtrl->GPIOStates;
						}
					CurrentByteIdx += SET_GPIO_REPLY_SIZE_BYTES;
					break;
					}

				case MUX_DATA_ID:	//	GPIO data received
					{
						GlobalCtrl->RxDataPtr = (void *)&GlobalCtrl->RxBuffer[CurrentByteIdx + 12];// 10 - RCV_DATA_FRAME_T+I2C conf data bytes
						ReleaseMutex(GlobalCtrl->hBufferMutex);
						WaitForSingleObject(GlobalCtrl->hBufferMutex, 100);
						CurrentByteIdx += MUX_DATA_SIZE;
						break;
					}

                default:
                    {
                    CurrentByteIdx++;
                    break;
                    }
			    }

            }
        else
            {
            CurrentByteIdx++;
            }

		FrameHdrPtr = (struct RCV_DATA_FRAME_T *)&GlobalCtrl->RxBuffer[CurrentByteIdx];
        }

}


DWORD SetRxTransferSize(struct GLOBAL_CTRL_T *GlobalCtrl)
{

	DWORD	dwRetcode;

	SetEvent(GlobalCtrl->hBreakCurrentBulkRead);

	dwRetcode = WaitForSingleObject(GlobalCtrl->hUSBReadMutex, 1000);	//	Wait maximum of 1 sec until ReadUSBPacket returns
	ReleaseMutex(GlobalCtrl->hUSBReadMutex);
	if(dwRetcode != WAIT_OBJECT_0)
		{
		return 14003;
		}

	//ZeroMemory(&BufIndexes, sizeof(BufIndexes));

	return 0;

}


void RxThreadFunc(PVOID pvoid)
{

    struct GLOBAL_CTRL_T	*GlobalCtrl;
    DWORD					ErrorCode;
	ULONG					ulRead;
	DWORD					dwRetcode;

    GlobalCtrl = (struct GLOBAL_CTRL_T *)pvoid;

	dwRetcode = WaitForSingleObject(GlobalCtrl->hBufferMutex, 1);	//	set the initial ownership to Rx thread
	if(dwRetcode != WAIT_OBJECT_0)
		{
		if(GlobalCtrl->DLLErrorEventPtr)
			{
			*GlobalCtrl->DLLErrorEventPtr = 14000L;	//	indicate DLL internal error from Rx thread
			}
		GlobalCtrl->IsRxReady = FALSE;
        _endthreadex(-1);
		}

    do
        {
		WaitForSingleObject(GlobalCtrl->hUSBReadMutex, 10);	//	used by SetRxTransferSize()

		ErrorCode = ReadUSBPacket(GlobalCtrl->hUSB, GlobalCtrl->RxBuffer, GlobalCtrl->RxRequestSizeBytes, &ulRead, INFINITE, GlobalCtrl->hBreakCurrentBulkRead); // INFINITE , GlobalCtrl->RxControl.hBreakCurrentBulkRead
        
		ReleaseMutex(GlobalCtrl->hUSBReadMutex);

		if(GlobalCtrl->RxRequestSizeBytes == ulRead)
            {
            if(ErrorCode != ERROR_SUCCESS)
                {
                if(ErrorCode == ERROR_GEN_FAILURE)	// Device was removed unexpectedly from the bus
                    {
					if(GlobalCtrl->DLLErrorEventPtr)
						{
						*GlobalCtrl->DLLErrorEventPtr = ErrorCode;
						}
					GlobalCtrl->IsRxReady = FALSE;
                    _endthreadex(-2);
                    }
				}
			else
				{
				ExtractData(GlobalCtrl, ulRead);
				if(GlobalCtrl->USBTransferNfoPtr)
					{
					GlobalCtrl->USBTransferNfoPtr[0] += ulRead;
					}
				}
			}
        else
            {
            if(ErrorCode == ERROR_GEN_FAILURE)
                {
				if(GlobalCtrl->DLLErrorEventPtr)	//	Check if calling application has saved the ErrorEvent pointer
					{
					*GlobalCtrl->DLLErrorEventPtr = ErrorCode;
					}
				GlobalCtrl->IsRxReady = FALSE;
				_endthreadex(-3);
                }
            }

        }
    while(GlobalCtrl->IsRxReady);

    _endthreadex(0);

}




DWORD GetStatStr(struct GLOBAL_CTRL_T *GlobalCtrl, LPSTR StrPtr)
{
	DWORD	dwRetcode;

	dwRetcode = WaitForSingleObject(GlobalCtrl->hBufferMutex, 100);
	if(dwRetcode != WAIT_OBJECT_0)
		{
		ReleaseMutex(GlobalCtrl->hBufferMutex);
		return IDS_NO_RESPONSE_ERROR;
		}

	memcpy_s(StrPtr, DEV_STATUS_TXT_SIZE_BYTES, GlobalCtrl->RxDataPtr, (STATUS_REPLY_SIZE_BYTES - 4));

	StrPtr[(STATUS_REPLY_SIZE_BYTES - 4)] = 0x00;	//	add \0 at end of the string

	ReleaseMutex(GlobalCtrl->hBufferMutex);	//	signal Rx thread that it can continue to wait next data frame

	return 0;
}

DWORD GetMuxStr(struct GLOBAL_CTRL_T *GlobalCtrl, LPSTR StrPtr)
{
	DWORD	dwRetcode;
	ULONG	Cnt;
	PBYTE	SrcBufferPtr;

	dwRetcode = WaitForSingleObject(GlobalCtrl->hBufferMutex, 500);
	if (dwRetcode != WAIT_OBJECT_0)
	{
		ReleaseMutex(GlobalCtrl->hBufferMutex);
		return IDS_NO_RESPONSE_ERROR;
	}
	memcpy_s(StrPtr, 12, GlobalCtrl->RxDataPtr, (12));
	
	//StrPtr[(13)] = 0x00;
	//OutputDebugStringW(StrPtr);

	//SrcBufferPtr = (PBYTE)GlobalCtrl->RxDataPtr;
	//for (Cnt = 0; Cnt < 12; Cnt++)
	//{
	//	StrPtr[Cnt] = SrcBufferPtr[(Cnt * 2)];	//	Copy even bytes from Rx buffer so that client software receives clean data
	//}

	ReleaseMutex(GlobalCtrl->hBufferMutex);

	return 0;
}



DWORD GetConfData(struct GLOBAL_CTRL_T *GlobalCtrl, PBYTE DestDataPtr)
{

	DWORD	dwRetcode;

	dwRetcode = WaitForSingleObject(GlobalCtrl->hBufferMutex, 100);
	if(dwRetcode != WAIT_OBJECT_0)
		{
		ReleaseMutex(GlobalCtrl->hBufferMutex);
		return IDS_NO_RESPONSE_ERROR;
		}

	memcpy_s(DestDataPtr, GETCONF_REPLY_SIZE_BYTES, GlobalCtrl->RxDataPtr, (GETCONF_REPLY_SIZE_BYTES - 4));

	ReleaseMutex(GlobalCtrl->hBufferMutex);

	return 0;

}


DWORD GetI2CData(struct GLOBAL_CTRL_T *GlobalCtrl, ULONG ByteCount, PBYTE DestDataPtr)
{
	DWORD	dwRetcode;
	ULONG	Cnt;
	PBYTE	SrcBufferPtr;

	dwRetcode = WaitForSingleObject(GlobalCtrl->hBufferMutex, 100);
	if(dwRetcode != WAIT_OBJECT_0)
		{
		ReleaseMutex(GlobalCtrl->hBufferMutex);
		return IDS_NO_SLAVE_RESPONSE_ERROR;
		}

	SrcBufferPtr = (PBYTE)GlobalCtrl->RxDataPtr;

	for(Cnt = 0; Cnt < ByteCount; Cnt++)
		{
		DestDataPtr[Cnt] = SrcBufferPtr[(Cnt * 2)];	//	Copy even bytes from Rx buffer so that client software receives clean data
		}

	ReleaseMutex(GlobalCtrl->hBufferMutex);

	return 0;
}




DWORD GetData(struct GLOBAL_CTRL_T *GlobalCtrl, ULONG DataSegmentCnt, PBYTE DstDataPtr, PULONG_PTR NrOfSegmentCapturedPtr)
{

	ULONG		n, PollPrd;
	DWORD		dwRetcode;


	if(GlobalCtrl->CurrentDeviceMode == MEASUREEXT)
		{
		PollPrd = 10000 + (GlobalCtrl->CurrentRxBufferMultiplier * GlobalCtrl->CurrentDividerValue);
		}
	else
		{
		PollPrd = 50 + (GlobalCtrl->CurrentRxBufferMultiplier * GlobalCtrl->CurrentDividerValue);
		}


    for(n = 0; n < DataSegmentCnt; n++)
        {
		//dwRetcode = WaitForMultipleObjects(2, hEvents, FALSE, PollPrd);
		dwRetcode = WaitForSingleObject(GlobalCtrl->ImpBufCtrl.hBufferReadyEvent, PollPrd);
		if(dwRetcode != WAIT_OBJECT_0)
			{
			if(NrOfSegmentCapturedPtr)
				{
				*(NrOfSegmentCapturedPtr) = n;
				}
			return IDS_DATA_POLL_TIMEOUT_ERROR;
			}
		if(GlobalCtrl->CurrentDeviceMode == IDLE)	//	for case when device switches from measurement to idle mode, return
			{
			if(NrOfSegmentCapturedPtr)
				{
				*(NrOfSegmentCapturedPtr) = n;
				}
			return 0;
			}

		memcpy_s(&DstDataPtr[(IMP_DATA_SIZE * n)], (IMP_DATA_SIZE * (DataSegmentCnt - n)), &GlobalCtrl->ImpedanceDataBuffer[GlobalCtrl->ImpBufCtrl.BufferOutIdx].AddressControl, IMP_DATA_SIZE);

		BufferUpdate(&GlobalCtrl->ImpBufCtrl, 0, 1, GlobalCtrl->DLLErrorEventPtr);
		}

	if(NrOfSegmentCapturedPtr)
		{
		*(NrOfSegmentCapturedPtr) = n;
		}

	return 0;

}


DWORD SendCtrlCmd(struct GLOBAL_CTRL_T *GlobalCtrl, USHORT CmdSizeWrd)
{
	ULONG	WrdCnt;
	ULONG	ulWritten;
	BYTE	*tmpTxBufferPtr;

	ULONG	ByteCnt = 0;
	DWORD	ErrorCode = ERROR_SUCCESS;


	tmpTxBufferPtr = (BYTE *)malloc((CmdSizeWrd * 2));

	for(WrdCnt = 0; WrdCnt < CmdSizeWrd; WrdCnt++)
		{
		tmpTxBufferPtr[ByteCnt++] = (BYTE)GlobalCtrl->CtrlCmdBuffer[WrdCnt];
		tmpTxBufferPtr[ByteCnt++] = (BYTE)(GlobalCtrl->CtrlCmdBuffer[WrdCnt] >> 8);
		}

	if(!WriteUSBPacket(GlobalCtrl->hUSB, tmpTxBufferPtr, ByteCnt, &ulWritten))
		{
	    //
	    // We failed to write the data for some reason.
	    //

		ErrorCode = GetLastError();		//	WinUSB write is not actually called so GetLastOperationErrorValue returns 0
		if(ErrorCode == ERROR_SUCCESS)
			{
			ErrorCode = ERROR_INVALID_PARAMETER;
			}
		}

	if(GlobalCtrl->USBTransferNfoPtr)
		{
		GlobalCtrl->USBTransferNfoPtr[1] += ByteCnt;
		}


	free(tmpTxBufferPtr);

	return ErrorCode;
}


